const Note = require('../models/note.model.js');

exports.create = (req, res) => {
    if(!req.body.company) {
        return res.status(400).send({
            message: "Note content can not be empty"
        });
    }

    const note = new Note({
        f_name: req.body.f_name || "Untitled Note", 
        l_name: req.body.l_name,
        company: req.body.company,
        contactNo: req.body.contactNo,
        email:req.body.email,
        address: req.body.address
    });

    note.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the Note."
        });
    });
};

exports.findAll = (req, res) => {
    Note.find()
    .then(notes => {
        res.send(notes);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving notes."
        });
    });
};
