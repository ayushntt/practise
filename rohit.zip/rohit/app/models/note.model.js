const mongoose = require('mongoose');

const NoteSchema = mongoose.Schema({
    f_name: String,
    l_name: String,
    company: String,
    contactNo: Number,
    email: String,
    address: String
}, {
    timestamps: true
});

module.exports = mongoose.model('Note', NoteSchema);