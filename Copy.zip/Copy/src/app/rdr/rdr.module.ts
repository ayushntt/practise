import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RdrComponent } from 'app/rdr/rdr.component';
import { HeaderComponent } from 'app/rdr/header/header.component';
import { RDRRoutingModule } from 'app/rdr/rdr-routing.module';
import { AllLineComponent } from 'app/rdr/all-line/all-line.component';
import { BmwCarComponent } from 'app/rdr/bmw-car/bmw-car.component';
import { MatDialogModule, MatDialogRef, MatDatepickerModule,
  MatFormFieldModule, MatNativeDateModule, MatInputModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FooterComponent } from './footer/footer.component';
import { RdrService } from './rdr.service';
import { InvalidAddressComponent } from './modals/invalid-address/invalid-address.component';
import { BmwLightComponent } from './bmw-light/bmw-light.component';
import { BmwMiniComponent } from './bmw-mini/bmw-mini.component';
import { BmwIComponent } from './bmw-i/bmw-i.component';
import { BmwCpoComponent } from './bmw-cpo/bmw-cpo.component';
import { BmwUsedComponent } from './bmw-used/bmw-used.component';




@NgModule({
  imports: [
    CommonModule,
    RDRRoutingModule,
    FormsModule,
    MatDialogModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatNativeDateModule,
    MatInputModule,
    BrowserAnimationsModule,
  ],
  entryComponents: [InvalidAddressComponent],
  providers: [RdrService],
  declarations: [
    RdrComponent,
    HeaderComponent,
    AllLineComponent,
    BmwCarComponent,
    FooterComponent,
    InvalidAddressComponent,
    BmwLightComponent,
    BmwMiniComponent,
    BmwIComponent,
    BmwCpoComponent,
    BmwUsedComponent,
  ],
  exports: [RdrComponent,
    MatDialogModule]
})
export class RDRModule {
  constructor() { }
}
