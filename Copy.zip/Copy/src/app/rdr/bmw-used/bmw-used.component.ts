import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bmw-used',
  templateUrl: './bmw-used.component.html',
  styleUrls: ['./bmw-used.component.css']
})
export class BmwUsedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
