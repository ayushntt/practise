import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bmw-cpo',
  templateUrl: './bmw-cpo.component.html',
  styleUrls: ['./bmw-cpo.component.css']
})
export class BmwCpoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
