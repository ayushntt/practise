import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bmw-car',
  templateUrl: './bmw-car.component.html',
  styleUrls: ['./bmw-car.component.css']
})
export class BmwCarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
