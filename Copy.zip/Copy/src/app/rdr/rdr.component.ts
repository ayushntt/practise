import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rdr',
  templateUrl: './rdr.component.html',
  styleUrls: ['./rdr.component.css']
})
export class RdrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
