import { Component, OnInit, AfterViewInit } from '@angular/core';
import { AllLineService } from 'app/rdr/all-line/all-line.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { AppService } from '../../app.service';
import { InvalidAddressComponent } from '../modals/invalid-address/invalid-address.component';

@Component({
  selector: 'app-all-line',
  templateUrl: './all-line.component.html',
  styleUrls: ['./all-line.component.css']
})
export class AllLineComponent implements OnInit, AfterViewInit {
  users: any;
  dialogRef: any;
  selectCount: number;
  constructor(public dialog: MatDialog) {
    this.selectCount = 0;
  }

  ngAfterViewInit() {
    // this.fetch();
  }
  ngOnInit() {
    this.fetch();
  }

  fetch() {
    // this.allService.getData().subscribe(res => {this.users = res
    //   console.log(this.users)
    //   });
  }

  // fetch() {
  //   this.allService.getData().subscribe(
  //     (users: any) => {
  //       this.users = users;
  //       console.log(users);
  //     },
  //     (error) => console.log(error)
  //   );
  // }
  // Pop-ups


  showPopup(type: string) {
    this.dialogRef = this.dialog.open(InvalidAddressComponent, {
    });
  }




  // end

  getVehicleType(isNew: string, isCPO: string) {
    if (isNew === 'N') {
      return 'New';
    } else if (isNew === 'U') {
      if (isCPO === 'Y') {
        return 'CPO';
      } else if (isCPO === 'N') {
        return 'Used';
      }
    }
  }

  updateCount(event: any, id: string) {
    if (event.target.checked) {
      this.selectCount++;
    } else if (!event.target.checked) {
      this.selectCount--;
    }
  }

  selectAll() {
    const checkboxes = document.getElementsByName('select');
    for (let i = 0; i < checkboxes.length; i++) {
      const element = <HTMLInputElement>checkboxes[i];
      element.checked = true;
    }
    this.selectCount = 30;
  }

  clearAll() {
    const checkboxes = document.getElementsByName('select');
    for (let i = 0; i < checkboxes.length; i++) {
      const element = <HTMLInputElement>checkboxes[i];
      element.checked = false;
    }
    this.selectCount = 0;
  }

}
