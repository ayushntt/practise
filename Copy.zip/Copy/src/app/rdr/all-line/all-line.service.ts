import { Injectable } from '@angular/core';
import { Http, Headers, Response, URLSearchParams } from '@angular/http';
import 'rxjs/Rx';


@Injectable({
    providedIn: 'root'
    })
export class AllLineService{
    result: any;
    constructor(private http: Http) {
        // this.vin = '';
        // this.prod = '';
        // this.params = new URLSearchParams();
      }
    getData() {
        return this.http.get('/dcsnetsales' + '/rest/v1/dataservice/retailList').map((response: Response) => {
            const data = response.json();
            return data;
          });
    }
}
