import { Injectable, EventEmitter } from '@angular/core';
import {Subject} from 'rxjs';
import { RDRModule } from './rdr.module';
import { RDRRoutingModule } from './rdr-routing.module';
@Injectable({
  providedIn: 'root'
})
export class RdrService {
  test: number;
  private notify = new Subject<any>();
  notifyObservable$ = this.notify.asObservable();
  openDialog = new EventEmitter<string>();
  openDialogForward = new EventEmitter<string>();
  constructor() {
    this.openDialog.subscribe(
      (type: string) => {
        if (type === 'invalidAddress') {
          this.openDialogForward.emit('invalidAddress');
        }
      }
    );
  }
  public notifyOther(data: any) {
    if (data) {
      this.notify.next(data);
    }
  }
}
