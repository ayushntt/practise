import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bmw-i',
  templateUrl: './bmw-i.component.html',
  styleUrls: ['./bmw-i.component.css']
})
export class BmwIComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
