import { Component, OnInit } from '@angular/core';
import {BmwSearch} from 'app/rdr/header/header.model'

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  date: string;
  status: string;
  chassisNbr: string;
  location: string;
  searchData: BmwSearch 
  isChecked: boolean
  constructor() { }

  ngOnInit() {
    this.searchData = {} as BmwSearch;
  }
  search(){
    console.log(this.searchData)
  }
  chassisNbrSelection()
  {
    document.getElementsByTagName("displaySearchBy").checked=false;
   let getElement= document.getElementById("chassisNbr");
   getElement.checked = true;
 
  }
  dateSelection()
{
  document.getElementsByTagName("displaySearchBy").checked=false;
   let getElement= document.getElementById("dateCheck");
   getElement.checked = true;
}  
statusDropdown(){
  document.getElementsByTagName("displaySearchBy").checked=false;
   let getElement= document.getElementById("statusDropdown");
   getElement.checked = true;
}
locationDropdown(){
  //document.getElementsByTagName("displaySearchBy").checked=false;
   let getElement= document.getElementById("locationCheck");
   getElement.checked = true;
}
}
