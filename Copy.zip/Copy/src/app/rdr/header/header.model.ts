export interface BmwSearch{
    date?: string;
    status?: string;
    chassisNbr?: string;
    location?: string;
    ineMakeId?: string;
    page?: number;
    sortColumn?: number;
    sortDirection?: number;
    dealerNumber?: string;
}