import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BmwMiniComponent } from './bmw-mini.component';

describe('BmwMiniComponent', () => {
  let component: BmwMiniComponent;
  let fixture: ComponentFixture<BmwMiniComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BmwMiniComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BmwMiniComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
