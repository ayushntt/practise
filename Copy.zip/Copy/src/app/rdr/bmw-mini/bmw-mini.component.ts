import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bmw-mini',
  templateUrl: './bmw-mini.component.html',
  styleUrls: ['./bmw-mini.component.css']
})
export class BmwMiniComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
