import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bmw-light',
  templateUrl: './bmw-light.component.html',
  styleUrls: ['./bmw-light.component.css']
})
export class BmwLightComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
