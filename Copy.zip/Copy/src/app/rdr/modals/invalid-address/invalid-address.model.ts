export interface InvalidAddressModel {
    corrections: Correction[];
    currentAvpPercentage: string;
    previousAvpPercentage: string;
    currentAvpInvalidAddrCount: string;
    previousAvpInvalidAddrCount: string;
    currentTotalRetailCountForAvp: string;
    previousTotalRetailCountForAvp: string;
    numOfItems: number;
}

export interface Correction {
    dealerNumber: string;
    id: number;
    location: string;
    type: string;
    status: string;
    date: Date;
    processDate: Date;
    vehicle: Vehicle;
    modBy: string;
    addByFname: string;
    addByLname: string;
    addDate: Date;
    modDate: Date;
    dateStr: string;
    processDateStr: string;
    transactionInd: string;
    errorCode: string;
    errorText: string;
    senderUserId: string;
    previousStatus: string;
    addReviewInd: string;
    avpPercent: number;
    disclaimerPrintedDate: Date;
    disclaimerPrintedDateStr: string;
    disclaimerPrintedBy: string;
    assignedToLocId: string;
    hasZRecordData: boolean;
    processDateStrForAddlZRecord: string;
    disclaimerPrintedDateStrForAddlZ: string;
    disclaimerPrintedByForAddlZ: string;
    needsZRecord: boolean;
    priorRetailedtoZ: boolean;
    updateRetailType: string;
}

export interface Vehicle {
    chassisNumber: string;
    type: string;
    lineMakeId: number;
    modelCode: string;
    cpoIndicator: string;
    telematicsInd: string;
    mileage: number;
    tireCodeFD: string;
    tireCodeFP: string;
    tireCodeRD: string;
    tireCodeRP: string;
    tireCodeSP: string;
    availibilityStatus: string;
    wholesaleDate: Date;
    modelDesc: string;
    modelYear: string;
    lineMakeDesc: string;
    statusDate: Date;
    optionCodes: string;
    autoType: string;
    auctionBidInd: string;
    naOrderPriorityCode: string;
    inventoryValidated: boolean;
    seriesCode: string;
    seriesDescription: string;
    inServiceDate: Date;
    inServiceDateStr: string;
    priorRetailedtoZ: boolean;
    modelCodeAndDesc: string;
    cpoIntention: string;
    telematicsCode: string;
    typeDesc: string;
}
