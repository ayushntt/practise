import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-invalid-address',
  templateUrl: './invalid-address.component.html',
  styleUrls: ['./invalid-address.component.css']
})
export class InvalidAddressComponent implements OnInit {
  constructor(public dialogRef: MatDialogRef<InvalidAddressComponent>) {}

  ngOnInit() {
  }

  closePopup() {
    this.dialogRef.close();
  }

}
