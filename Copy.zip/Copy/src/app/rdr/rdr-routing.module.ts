import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import {AllLineComponent} from 'app/rdr/all-line/all-line.component';
import {BmwCarComponent} from 'app/rdr/bmw-car/bmw-car.component';
import { BmwLightComponent } from './bmw-light/bmw-light.component';
import { BmwMiniComponent } from './bmw-mini/bmw-mini.component';
import { BmwIComponent } from './bmw-i/bmw-i.component';
import { BmwCpoComponent } from './bmw-cpo/bmw-cpo.component';
import { BmwUsedComponent } from './bmw-used/bmw-used.component';

const firstRoute: Routes = [
  {path: '', redirectTo: 'allLineMakers', pathMatch: 'full'},
  {path: 'allLineMakers', component: AllLineComponent},
  {path: 'bmwCar', component: BmwCarComponent},
  {path : 'bmwLight', component:BmwLightComponent},
  {path : 'bmwMini', component:BmwMiniComponent},
  {path : 'bmwI', component:BmwIComponent},
  {path : 'bmwCpo', component:BmwCpoComponent},
  {path : 'bmwUsed', component:BmwUsedComponent}
];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(firstRoute)
  ],
  exports: [RouterModule],
  declarations: []
})
export class RDRRoutingModule { }
