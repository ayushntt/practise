import { Injectable, EventEmitter } from '@angular/core';
import { RDRModule } from './rdr/rdr.module';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  constructor() { }
}
