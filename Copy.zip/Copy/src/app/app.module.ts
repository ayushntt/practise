import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AllLineService} from 'app/rdr/all-line/all-line.service';
import { AppComponent } from './app.component';
// import { RdrComponent } from './rdr/rdr.component';
// import { AllLineComponent } from './rdr/all-line/all-line.component';
// import { BmwCarComponent } from './rdr/bmw-car/bmw-car.component';
// import { HeaderComponent } from './rdr/header/header.component';
import {RDRModule} from 'app/rdr/rdr.module';
import { HttpModule } from '@angular/http';

@NgModule({
  declarations: [
    AppComponent,
    // RdrComponent,
    // AllLineComponent,
    // BmwCarComponent,
    // HeaderComponent,
  ],
  imports: [
    RDRModule,
    BrowserModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
