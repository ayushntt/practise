import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-modify',
  templateUrl: './add-modify.component.html',
  styleUrls: ['./add-modify.component.css']
})
export class AddModifyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
