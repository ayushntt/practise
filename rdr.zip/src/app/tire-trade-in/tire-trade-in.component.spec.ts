import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TireTradeInComponent } from './tire-trade-in.component';

describe('TireTradeInComponent', () => {
  let component: TireTradeInComponent;
  let fixture: ComponentFixture<TireTradeInComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TireTradeInComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TireTradeInComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
