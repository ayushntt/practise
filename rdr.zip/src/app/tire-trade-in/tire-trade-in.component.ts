import { Component, OnInit } from '@angular/core';

export interface Telematic {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-tire-trade-in',
  templateUrl: './tire-trade-in.component.html',
  styleUrls: ['./tire-trade-in.component.css']
})
export class TireTradeInComponent implements OnInit {

  telematics: Telematic[] = [
    {value: 'ineligible', viewValue: 'Ineligible'},
    {value: 'abhijeet', viewValue: 'Ineligible'}
  ];

  constructor() { }

  ngOnInit() {
  }

}
