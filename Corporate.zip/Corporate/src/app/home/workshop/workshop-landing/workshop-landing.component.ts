import { Component, OnInit } from '@angular/core';
import { WorkshopLandingService } from './workshop-landing.service';

@Component({
  selector: 'app-workshop-landing',
  templateUrl: './workshop-landing.component.html',
  styleUrls: ['./workshop-landing.component.css']
})
export class WorkshopLandingComponent implements OnInit {

  constructor( private workLandingService: WorkshopLandingService) { }

  ngOnInit() {
    this.fetchData();
  }
  fetchData(){
    this.workLandingService.getSearchData().subscribe();
  }
}
