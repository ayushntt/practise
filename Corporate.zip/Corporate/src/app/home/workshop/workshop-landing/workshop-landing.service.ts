import{Injectable} from '@angular/core'

import {Http,Response,Headers,RequestOptions} from '@angular/http'
import {searchData} from 'app/core/resource/resource.config'
import { CorporateResourceService } from "app/core/resource/resource.service";
import { ICorporateResourcePayload , ICorporateServerResponse } from 'app/core/resource/resource.model';
@Injectable({
    providedIn: 'root'
})
export class WorkshopLandingService{
    constructor( private resourceService: CorporateResourceService ){}

    getSearchData(){
        let payload: ICorporateResourcePayload = {
            uri: searchData.uri,
            method: searchData.method,
            body: searchData
        }
        return this.resourceService.request(searchData, payload);
    }
} 