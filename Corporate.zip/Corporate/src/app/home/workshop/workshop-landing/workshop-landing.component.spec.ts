import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkshopLandingComponent } from './workshop-landing.component';

describe('WorkshopLandingComponent', () => {
  let component: WorkshopLandingComponent;
  let fixture: ComponentFixture<WorkshopLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkshopLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkshopLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
