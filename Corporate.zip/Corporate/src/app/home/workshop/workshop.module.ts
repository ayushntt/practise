import { NgModule } from '@angular/core';
import { WorkshopComponent } from 'app/home/workshop/workshop.component';
import { WorkshopLandingComponent } from './workshop-landing/workshop-landing.component';
import { WorkshopRoutingModule } from './workshop-routing.module';
@NgModule({
  declarations: [  
  WorkshopComponent, WorkshopLandingComponent,  
  ],
  imports: [
    WorkshopRoutingModule
  ],
  providers: [],
  bootstrap: [],
  exports:[WorkshopComponent]
})
export class WorkshopModule { }