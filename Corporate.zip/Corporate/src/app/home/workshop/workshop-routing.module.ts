import { NgModule } from '@angular/core';
import {CommonModule} from '@angular/common'
import { Routes, RouterModule } from '@angular/router';
import { WorkshopLandingComponent } from './workshop-landing/workshop-landing.component';

const routes: Routes=[
    {path:'', redirectTo:'workshopLanding', pathMatch:'full'},
    {path:'workshopLanding', component: WorkshopLandingComponent}
];
@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes)
    ],
    exports:[RouterModule]
})
export class WorkshopRoutingModule{
    constructor(){console.log("workshop Called")}
}