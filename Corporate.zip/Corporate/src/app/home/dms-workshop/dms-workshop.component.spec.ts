import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DmsWorkshopComponent } from './dms-workshop.component';

describe('DmsWorkshopComponent', () => {
  let component: DmsWorkshopComponent;
  let fixture: ComponentFixture<DmsWorkshopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DmsWorkshopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmsWorkshopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
