import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dms-workshop',
  templateUrl: './dms-workshop.component.html',
  styleUrls: ['./dms-workshop.component.css']
})
export class DmsWorkshopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
