import { NgModule } from '@angular/core';
import { DmsWorkshopComponent } from './dms-workshop.component';
import { DmsLandingComponent } from './dms-landing/dms-landing.component';
import { DMSWorkshopRoutingModule } from './dms-workshop-routing.module';
@NgModule({
  declarations: [  
  DmsWorkshopComponent, DmsLandingComponent,  
  ],
  imports: [
    DMSWorkshopRoutingModule
      ],
  providers: [],
  bootstrap: [],
  exports:[DmsWorkshopComponent]
})
export class DMSWorkshopModule { }