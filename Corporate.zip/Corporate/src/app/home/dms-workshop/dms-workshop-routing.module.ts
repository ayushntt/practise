import { NgModule } from '@angular/core';
import {CommonModule} from '@angular/common'
import { Routes, RouterModule } from '@angular/router';
import { DmsLandingComponent } from './dms-landing/dms-landing.component';
const routes: Routes=[
    {path:'', redirectTo:'DMSLanding', pathMatch:'full'},
    {path:'DMSLanding', component: DmsLandingComponent}
];
@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes)
    ],
    exports:[RouterModule]
})
export class DMSWorkshopRoutingModule{
    constructor(){console.log("DMSworkshop Called")}
}