import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DmsLandingComponent } from './dms-landing.component';

describe('DmsLandingComponent', () => {
  let component: DmsLandingComponent;
  let fixture: ComponentFixture<DmsLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DmsLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmsLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
