import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dms-landing',
  templateUrl: './dms-landing.component.html',
  styleUrls: ['./dms-landing.component.css']
})
export class DmsLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
