import { NgModule, Optional, SkipSelf, ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { CorporateErrorService } from 'app/core/error/error.service';
import { CorporateResourceService } from 'app/core/resource/resource.service';
import { CorporateErrorHandler } from 'app/core/error/error.handler.service';

@NgModule({
    imports: [CommonModule, HttpClientModule],
    providers:[CorporateErrorHandler,CorporateErrorService, CorporateResourceService]
})

export class CorporateCoreModule{
    constructor (@Optional() @SkipSelf() parentModule: CorporateCoreModule) {
        if (parentModule) {
            throw new Error('CorporateCoreModule is already loaded. Import it in the AppModule only');
        }
    }
}