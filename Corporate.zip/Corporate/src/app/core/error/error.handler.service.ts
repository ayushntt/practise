import { Injectable, ErrorHandler} from '@angular/core';

import {CorporateErrorService} from './error.service';
import { CorporateError } from "app/core/error/error.model";

@Injectable()
export class CorporateErrorHandler extends ErrorHandler{
    
    constructor(private errorService: CorporateErrorService) {
        super();
    }

    handleError(error: any): void {
        this.errorService.logError(error);
    }
}