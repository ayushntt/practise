import { Injectable } from '@angular/core';
import { Response } from '@angular/http';

import {CorporateMessages} from 'app/core/messages/messages.constants';
import { CorporateError } from "app/core/error/error.model";

@Injectable()
export class CorporateErrorService {

    constructor() { 
    }

    logError(error: any){
        let crprtError : CorporateError;
        if(error instanceof Error){
            crprtError = (<CorporateError>error);
        }else{
            crprtError = new CorporateError(`Unknown Error`);
            crprtError.details = JSON.stringify(error);
        }
        this.printConsole(crprtError);       
    }

    private printConsole(error: CorporateError){
        let printErr = 
        `Error:${error.code? error.code: ''} ${error.message}
        ${error.details? error.details: ''}
        ${error.stack}`;
        console.error(printErr);
    }
}