export class CorporateError extends Error {
    code: number;
    private _details: string;

    constructor(errorMessage: string, errorCode?: number, stack?: string) {
        super(errorMessage);
        if(errorCode){
            this.code =errorCode;
        }        
        if(stack){
            this.stack = stack;
        }        
     }

     set details(details:string){
        this._details = details;
     }

     get details(): string{
        return this._details;
     }
}
