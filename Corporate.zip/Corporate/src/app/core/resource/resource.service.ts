import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Http, Response, Headers, RequestOptions, ResponseContentType } from '@angular/http'

import { environment } from '../../../environments/environment';
 import {AppConstants} from 'app/app.constants';
import { ICorporateResourceApi , ICorporateResourcePayload, CorporateRequestType, CorporateResponseType, CorporateHttpMethods} from "./resource.model";
 import { CorporateError } from "app/core/error/error.model";
// import { CffAuthService } from "app/core/auth/auth.service";
 import { CorporateMessages } from "app/core/messages/messages.constants";
import { Router } from "@angular/router";
import { error } from 'util';


@Injectable()
export class CorporateResourceService {

    apiEndpoint: string;
    defaultHeaders: {[name: string]: any};
    defaultRequestType: CorporateRequestType;
    authHeader: {[name: string]: any};

    constructor(private http: Http, private router: Router) { 
        this.apiEndpoint = environment.apiEndpoint;
        this.defaultHeaders = {};
        this.defaultRequestType = CorporateRequestType.Json;
    }

    request(api: ICorporateResourceApi, payload: ICorporateResourcePayload): Observable<any>{
        //1. Construct url
        let url = this.buildUrl(api, payload);
        //2. Append headers to default ones
        //3. Check if resource is secured and set authorization header 
        //4. Check request type and set content-type
        let headers = new Headers(this.buildHeaders(api, payload));
        let options = new RequestOptions({headers: headers});
        //4. Check method type and forward to appropriate function
        // override responseType for blob
        if(api.responseType == CorporateResponseType.Blob) {
            options = new RequestOptions({responseType: ResponseContentType.Blob,headers: headers});
        }
        let response = this.sendRequest(url, api.method, options, this.buildBody(api, payload));
        //5. Check response type and extract data
        return this.handleResponse(api, response);                
    }

    private buildUrl(api: ICorporateResourceApi, payload: ICorporateResourcePayload): string{
        let allowedParams = api.params;
        let url = api.uri;
        let searchUri = ''; 

        // find path variables in the uri
        if (allowedParams) {
            allowedParams.forEach(value => {
                if (url.includes(`/:${value}`) && payload.params[value]) {
                    url = url.replace(`/:${value}`, `/${payload.params[value]}`);
                } else if (payload.params[value]) {
                    searchUri === '' ? searchUri = `?${value}=${encodeURIComponent(payload.params[value])}` : searchUri = `${searchUri}&${value}=${encodeURIComponent(payload.params[value])}`;
                }
            })
        }
        url = `${this.apiEndpoint}${url}${searchUri}`;
        return url;
    }

    private buildHeaders(api: ICorporateResourceApi, payload: ICorporateResourcePayload) : {[name: string]: any}{
        let headers = {};        
        let requestType = this.defaultRequestType;
        if(api.requestType){
            requestType = api.requestType;
        }
        switch(requestType){
            case CorporateRequestType.Json: {
                Object.assign(headers, this.defaultHeaders);
            }                   
        }        
        if(api.secured && this.authHeader){
           Object.assign(headers, this.authHeader);
        }
        Object.assign(headers, api.headers, payload.headers);
        return headers;
    }

    private buildBody(api: ICorporateResourceApi, payload: ICorporateResourcePayload){
        let requestType = this.defaultRequestType;
        if(api.requestType){
            requestType = api.requestType;
        }
        if(requestType === CorporateRequestType.Json){
            return JSON.stringify(payload.body);
        }else{
            return payload.body;
        }
    }

    private sendRequest(url: string, method: CorporateHttpMethods, options: RequestOptions, data: any) : Observable<Response>{
        let response: Observable<Response>;
        switch(method) {
            case CorporateHttpMethods.GET: {
                response = this.http.get(url, options);
                break;
            }
            case CorporateHttpMethods.POST: {
                response = this.http.post(url, data, options);
                break;
            }                
            case CorporateHttpMethods.PATCH: {
                response = this.http.patch(url, data, options);
                break;
            }               
            case CorporateHttpMethods.PUT: {
                response = this.http.put(url, data, options);
                break;
            }                
            case CorporateHttpMethods.DELETE:{
                response = this.http.delete(url, options);
                break;
            }                
            default:
                return this.handleError("HTTP Method not supported");
        }
        return response;
    }

    private handleResponse(api: ICorporateResourceApi, response: Observable<any>): Observable<any>{
        return response.map(res => {
            console.log(res)
            if(res._body){
                let contentType = res.headers.get(AppConstants.headerContentType);
                if(contentType.includes('json') && api.responseType === CorporateResponseType.Json){
                    return res.json();
                }else if(contentType.includes('image') && 
                        api.responseType === CorporateResponseType.Image){
                    return `data:${contentType};base64,${res.json()}`;        
                }
                else if(!contentType.includes('json') && !contentType.includes('image') && 
                    api.responseType === CorporateResponseType.Image){
                return `data:${contentType};base64,${res.json()}`;        
                }else if(!contentType.includes('json') && !contentType.includes('image') && !contentType.includes('image') && 
                        api.responseType === CorporateResponseType.Blob){
                    let filename = res.headers.get('filename');
                    return {filename:filename,blob:res._body};
                } else{
                    return res._body;
                }
            }
        })
        .catch((err: Response) => {
            if(err.status === 401){
                this.router.navigate(['login']);
            }
            throw this.buildHttpError(err);
        });;
    }

    private handleError(message:string) : Observable<any>{
        return Observable.throw(new CorporateError(message));
    }

    setAuthHeader(authToken: string){
        this.authHeader = {};
        this.authHeader[AppConstants.headerAuthorization] = authToken;
    }

    clearAuthHeader(){
        this.authHeader = undefined;
    }

    private buildHttpError(httpResponse: Response) : CorporateError{
        let error : CorporateError;    
        let contentType = httpResponse.headers.get(AppConstants.headerContentType);    
        let details = 
        `Details:-
        URL: ${httpResponse.url}
        Headers: ${JSON.stringify(httpResponse.headers)}`;
                
        if ((<any>httpResponse)._body) {
            if (contentType.includes('json')) {
                let errBody = httpResponse.json();
                if (Array.isArray(errBody)) {
                    let errMessage = this.buildErrorMessage(errBody);
                    if(errMessage !== ''){
                        error = new CorporateError(errMessage, httpResponse.status); 
                    }
                } else if (typeof errBody === 'object') {
                    if(errBody.message){
                        error = new CorporateError(errBody.message, httpResponse.status); 
                    }                    
                }              
            }else{
                error = new CorporateError((<any>httpResponse)._body, httpResponse.status); 
            }
        }
        if(!error){
            error = new CorporateError(`HTTP Error ${httpResponse.status}`, httpResponse.status); 
        }
        error.details = `${details}
        Message: ${error.message}`
        if(CorporateMessages['HTTP_'+ httpResponse.status]){
            error.details = `${error.details}
            Error: ${CorporateMessages['HTTP_'+ httpResponse.status]}`
        }
        return error;
    }

    private buildErrorMessage(errBody: any[]){
        let message: string = '';
        errBody.forEach(err => message = `${message} ${err.message}`);
        return message;
    }
}