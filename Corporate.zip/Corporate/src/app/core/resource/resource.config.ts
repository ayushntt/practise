import {ICorporateResourceApi, CorporateHttpMethods, CorporateRequestType, CorporateResponseType} from './resource.model';

export const searchData : ICorporateResourceApi ={
    uri: '/auth',
    method: CorporateHttpMethods.POST,
    secured: false,
    responseType: CorporateResponseType.Json
}