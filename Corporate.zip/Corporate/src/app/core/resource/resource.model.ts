export enum CorporateHttpMethods {
    GET, POST, PUT, DELETE, PATCH
}

export enum CorporateRequestType {
    Json, Image
}

export enum CorporateResponseType {
    Json, Image, None, Blob
}

export interface ICorporateResourceApi {
    uri: string;
    method: CorporateHttpMethods;
    headers?: {[name: string]: any};
    params?: string[];
    secured: boolean;
    requestType?: CorporateRequestType;
    responseType: CorporateResponseType;
}

export interface ICorporateResourcePayload {
    uri: string;
    method: CorporateHttpMethods;
    headers?: {[name: string]: any};
    params?: {[name: string]: any};
    responseType?: CorporateResponseType;
    body?: any;
}

export interface ICorporateServerResponse{
    _links?: any;
    createdDate?: string;
    deleted?: boolean;
    _embedded?: any;
    lastModifiedDate?: string;
    version?: number;
    message?: string;
}