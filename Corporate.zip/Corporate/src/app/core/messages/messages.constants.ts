export const CorporateMessages ={
    /** HTTP Status Messages */
    HTTP_400: 'Bad Request: The request cannot be fulfilled due to bad syntax.',
    HTTP_401: 'Unauthorized: Authentication has failed or not yet been provided.',
    HTTP_403: 'Forbidden: Client does not have access rights to the content.',
    HTTP_404: 'Not Found: The requested resource could not be found.',
    HTTP_405: 'Method Not Allowed: A request was made using a request method not supported by the resource.',
}