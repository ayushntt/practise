// import { Injectable } from '@angular/core';
// import{environment} from "environments/environment"
// import { Http, Headers, RequestOptions } from '@angular/http';
// import { HttpClient } from '@angular/common/http';
// import 'rxjs/add/operator/map';

// @Injectable()
// export class AppService {
//   public token: string;
//   result:any;
//   apiEndpoint: string;
//   constructor(private _http: Http) { 
//     this.apiEndpoint = environment.apiEndpoint
//   }

//   getUsers() {
//     return this._http.get(this.apiEndpoint + "/notes")
//       .map(res => this.result = res.json());
//   }
// }