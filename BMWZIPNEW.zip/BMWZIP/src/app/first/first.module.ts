import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FirstComponent } from 'app/first/first.component';
import { HeaderComponent } from './header.component';
import {FirstRoutingModule} from 'app/first/first-routing.module'
import{FirstTabComponent} from 'app/first/first-tab/first-tab.component'
import{SecondTabComponent} from 'app/first/second-tab/second-tab.component'
import{rcdComponent} from 'app/first/first-tab/rcd.component'


@NgModule({
  imports: [
    CommonModule,
    FirstRoutingModule,
    FormsModule
  ],
  declarations: [FirstComponent, HeaderComponent, FirstTabComponent, SecondTabComponent, rcdComponent],
  exports:[FirstComponent],
  entryComponents:[rcdComponent]
})
export class FirstModule {
  constructor(){console.log("first called")}
 }
