import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule,Routes } from '@angular/router'
import{FirstTabComponent} from 'app/first/first-tab/first-tab.component'
import{SecondTabComponent} from 'app/first/second-tab/second-tab.component'

const firstRoute : Routes=[
  {path: '', redirectTo: 'tab1', pathMatch: 'full'},
  {path:'tab1', component:FirstTabComponent},
  {path:'tab2', component:SecondTabComponent}
] 
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(firstRoute)
  ],
  exports:[RouterModule],
  declarations: []
})
export class FirstRoutingModule { }
