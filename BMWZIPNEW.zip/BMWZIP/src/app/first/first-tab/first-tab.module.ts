import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FirstTabComponent } from 'app/first/first-tab/first-tab.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [FirstTabComponent],
  exports:[]
})
export class FirstTabModule {
  constructor(){console.log("first-tab called")}
 }
