import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { NgForm } from "@angular/forms";
// import { BMWModalService } from "app/core/modal/modal.service";
// import { IBMWModalBody } from "app/core/modal/modal.model";

@Component({
    templateUrl: 'rcd.component.html',
    styleUrls: ['rcd.component.css']
})
export class rcdComponent implements OnInit{
data:any
deatil:any
@ViewChild('rcdForm') rcdForm: NgForm;
ngOnInit(){
    if(this.data && this.data.temp)
        {
            this.deatil= this.data.temp;
        }
        console.log(this.deatil)
}
}