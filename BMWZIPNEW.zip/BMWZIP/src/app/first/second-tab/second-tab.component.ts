import { Component, OnInit } from '@angular/core';
import{ISecond} from 'app/first/second-tab/second.model'

@Component({
  selector: 'app-second-tab',
  templateUrl: './second-tab.component.html',
  styleUrls: ['./second-tab.component.css']
})
export class SecondTabComponent implements OnInit {
  secondFormData:ISecond;
  constructor() { }

  ngOnInit() {
    this.secondFormData = {} as ISecond;
  }
  save(){
    console.log(this.secondFormData)
  }

}
