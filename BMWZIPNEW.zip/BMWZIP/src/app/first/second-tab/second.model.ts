export interface ISecond{
    Fname?: string;
    Lname?: string;
    company?: string;
    contact?: string;
    EmailId?: string;
    Address?: string;
}