import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SecondTabComponent } from 'app/first/second-tab/second-tab.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [SecondTabComponent],
  exports:[]
})
export class SecondTabModule {
  constructor(){console.log("second-tab module called")}
 }
