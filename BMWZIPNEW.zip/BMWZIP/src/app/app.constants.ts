export const AppConstants = {
    headerContentType : 'Content-Type',
    contentTypeJson : 'application/hal+json', 
    contentTypeImage : 'multipart/form-data',
    headerAuthorization : 'Authorization',
    authToken: "auth_token",
} 
