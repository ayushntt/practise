export enum BMWHttpMethods {
    GET, POST, PUT, DELETE, PATCH
}

export enum BMWRequestType {
    Json, Image
}

export enum BMWResponseType {
    Json, Image, None, Blob
}

export interface IBMWResourceApi {
    uri: string;
    method: BMWHttpMethods;
    headers?: {[name: string]: any};
    params?: string[];
    secured: boolean;
    requestType?: BMWRequestType;
    responseType: BMWResponseType;
}

export interface IBMWResourcePayload {
    uri: string;
    method: BMWHttpMethods;
    headers?: {[name: string]: any};
    params?: {[name: string]: any};
    responseType?: BMWResponseType;
    body?: any;
}

export interface IBMWServerResponse{
    _links?: any;
    createdDate?: string;
    deleted?: boolean;
    _embedded?: any;
    lastModifiedDate?: string;
    version?: number;
    message?: string;
}