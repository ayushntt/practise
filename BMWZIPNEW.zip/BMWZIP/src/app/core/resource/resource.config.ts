import {IBMWResourceApi, BMWHttpMethods, BMWRequestType, BMWResponseType} from './resource.model';

export const tabList : IBMWResourceApi={
    uri: '/notes',
    method: BMWHttpMethods.GET,
    secured:true,
    responseType: BMWResponseType.Json
}