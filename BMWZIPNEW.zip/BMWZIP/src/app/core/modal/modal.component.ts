import { Component, OnInit, Input, ViewChild, ViewContainerRef } from '@angular/core';
import {BMWModalService} from './modal.service';
import {BMWModalOptions} from './modal.options';
import {IBMWBaseModal} from './modal.model';

@Component({
    selector: 'cff-modal',
    templateUrl: 'modal.component.html',
    styleUrls: ['modal.component.css']
})

export class BMWModalComponent implements OnInit, IBMWBaseModal {
    options: BMWModalOptions;
    @ViewChild('modalBody', {read: ViewContainerRef}) bodyContainer : ViewContainerRef;

    constructor(private modalService: BMWModalService) { }

    ngOnInit() {
        this.modalService.register(this);
        this.options = new BMWModalOptions();
    }

    close(){
        this.modalService.close(this.options.modalId);
    }

    ngOnDestroy() {
        this.modalService.clearBase();
    }
}