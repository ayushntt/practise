export class BMWModalOptions {

    modalId: string;

    modalTitle: string;

    modalSubtitle: string;

    showClose: boolean;

    showSubtitle: boolean;

    backdrop: boolean|string;

    keyboard: boolean;

    constructor(){
        this.showClose = true;
        this.showSubtitle = false;
        this.backdrop = "static";
        this.keyboard = false;
    }
}