import { Injectable, Inject, ComponentFactoryResolver, ApplicationRef, ViewContainerRef, Type, Injector, ComponentRef, ReflectiveInjector } from '@angular/core';
import {BMW_JQ_TOKEN} from '../../external/jquery.service';
import {BMWModalComponent} from './modal.component';
import {BMWModalOptions} from './modal.options';
import {IBMWModalBody, IBMWBaseModal} from './modal.model';
import { Subject, Observable } from "rxjs/Rx";

@Injectable()
export class BMWModalService {
    baseModal : IBMWBaseModal; 
    private bodyComponentRef: ComponentRef<IBMWModalBody>;   
    openModals: {[name: string]: Subject<boolean>};
        
    constructor(@Inject(BMW_JQ_TOKEN) private $: any, private ref: ApplicationRef) {
        this.openModals = {};
     }

    close(modalId: string): void{
        if(this.$(`#${modalId}`).length){
            this.$(`#${modalId}`).modal("hide");
        }        
        this.openModals[modalId].next(true);
        delete this.openModals[modalId];
    }

    open(bodyComponent: Type<IBMWModalBody>, options:BMWModalOptions, data:any, componentFactoryResolver: ComponentFactoryResolver, injector: Injector){
        if(!options || !options.modalId){
            console.error("modalId not defined for the modal!");
            return;
        }
        this.loadModalBody(bodyComponent, options, data, componentFactoryResolver, injector);
        this.applyOptions(options);
        this.ref.tick();
        if(!this.$(`#${options.modalId}`).length){
            console.error("element with id '"+ options.modalId +"' does not exist!");
            return;
        }
        this.$(`#${options.modalId}`).modal({
            backdrop: options.backdrop,
            keyboard: options.keyboard
        });
        this.openModals[options.modalId] = new Subject<boolean>();
    }

    onClose(modalId: string) : Observable<boolean>{
        if(this.openModals[modalId]){
           return this.openModals[modalId].asObservable();
        }        
    }

    register(baseComponent: IBMWBaseModal){

        this.baseModal = baseComponent;
    }

    private loadModalBody(bodyComponent: Type<IBMWModalBody>, options:BMWModalOptions, data:any, componentFactoryResolver: ComponentFactoryResolver, injector: Injector){
        this.clearBase();
        const componentFactory = componentFactoryResolver.resolveComponentFactory(bodyComponent);
        const refInjector = ReflectiveInjector.resolveAndCreate([{provide: bodyComponent, useValue: bodyComponent}], injector);
        this.bodyComponentRef = this.baseModal.bodyContainer.createComponent(componentFactory, 0, refInjector);   
        this.bodyComponentRef.instance.data = data;  
    }

    clearBase(){
        this.baseModal.bodyContainer.clear();
        if (this.bodyComponentRef) { this.bodyComponentRef.destroy(); }
    }

    private applyOptions(options:BMWModalOptions){
        this.baseModal.options.modalId = options.modalId;
        this.baseModal.options.modalTitle = options.modalTitle;
        this.baseModal.options.modalSubtitle = options.modalSubtitle;
        if(options.backdrop !== undefined){
            this.baseModal.options.backdrop = options.backdrop;
        }
        if(options.keyboard !== undefined){
            this.baseModal.options.keyboard = options.keyboard;
        }
        if(options.showClose !== undefined){
            this.baseModal.options.showClose = options.showClose;
        }
        if(options.showSubtitle !== undefined){
            this.baseModal.options.showSubtitle = options.showSubtitle;
        }
    }
}