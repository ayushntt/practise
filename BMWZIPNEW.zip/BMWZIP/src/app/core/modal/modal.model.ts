import {ViewContainerRef} from '@angular/core';
import {BMWModalOptions} from './modal.options';

export interface IBMWModalBody {  
  data:any;
}

export interface IBMWBaseModal {
  bodyContainer: ViewContainerRef;
  options: BMWModalOptions;
}
