import { Injectable, ErrorHandler} from '@angular/core';

import {BMWErrorService} from 'app/core/error/error.service';
import { BMWError } from "./error.model";

@Injectable()
export class BMWErrorHandler extends ErrorHandler{
    
    constructor(private errorService: BMWErrorService) {
        super();
    }

    handleError(error: any): void {
        this.errorService.logError(error);
    }
}