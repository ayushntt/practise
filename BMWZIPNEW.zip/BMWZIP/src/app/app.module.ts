import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import {FirstModule} from 'app/first/first.module'
import {AppService} from "app/first/first-tab/first-tab.service";
import { HttpModule } from '@angular/http';
import {BMWCoreModule} from 'app/core/core.module'
import { BMW_JQ_TOKEN, JQUERY_PROVIDER } from './external/jquery.service';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FirstModule,
    FormsModule,
    HttpModule,
    BMWCoreModule
  ],
   providers: [AppService,JQUERY_PROVIDER],
  bootstrap: [AppComponent]
})
export class AppModule { 
  constructor(){console.log("app called")}
}
