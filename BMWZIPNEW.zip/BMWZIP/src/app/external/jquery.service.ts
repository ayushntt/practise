import {InjectionToken} from '@angular/core';

export const BMW_JQ_TOKEN = new InjectionToken('jQuery');

export function jQueryFactory() {
    return window['jQuery'];
}

export const JQUERY_PROVIDER = [
    { provide: BMW_JQ_TOKEN, useFactory: jQueryFactory },
];