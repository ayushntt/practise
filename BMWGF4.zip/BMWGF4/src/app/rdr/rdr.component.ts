import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rdr',
  templateUrl: './rdr.component.html',
  styleUrls: ['./rdr.component.css']
})
export class RDRComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}