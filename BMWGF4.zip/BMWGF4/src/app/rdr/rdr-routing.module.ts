import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule,Routes } from '@angular/router'
import{AllLineComponent} from 'app/rdr/allLine/allLine.component'
import{BMWCarComponent} from 'app/rdr/bmwCar/bmwCar.component'

const firstRoute : Routes=[
  {path: '', redirectTo: 'allLineMakers', pathMatch: 'full'},
  {path:'allLineMakers', component:AllLineComponent},
  {path:'bmwCar', component:BMWCarComponent}
] 
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(firstRoute)
  ],
  exports:[RouterModule],
  declarations: []
})
export class RDRRoutingModule { }
