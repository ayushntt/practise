import { Component, OnInit } from '@angular/core';
//import{ISecond} from 'app/first/second-tab/second.model'

@Component({
  selector: 'bmwCar',
  templateUrl: './bmwCar.component.html',
  styleUrls: ['./bmwCar.component.css']
})
export class BMWCarComponent implements OnInit {
  //secondFormData:ISecond;
  constructor() { }

  ngOnInit() {
      console.log("this is called")
   // this.secondFormData = {} as ISecond;
  }
  save(){
   // console.log(this.secondFormData)
  }

}
