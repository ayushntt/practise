import { Component, OnInit, ViewChild, Injector, ComponentFactoryResolver } from '@angular/core';
import {AllLineService} from "app/rdr/allLine/allLine.service";
import{IBMWUsers,IBMWRetail,IBMWVehicle} from 'app/rdr/allLine/allLine.model'
//import{BMWModalOptions} from 'app/core/modal/modal.options'
//import{BMWModalService} from 'app/core/modal/modal.service'
import { NgForm } from "@angular/forms";
import { Router } from '@angular/router'
@Component({
  selector: 'allLine-tab',
  templateUrl: './allLine.component.html',
  styleUrls: ['./allLine.component.css']
})
export class AllLineComponent implements OnInit {
 users: any;
 @ViewChild('retailDetails') rcdForm: NgForm;
 //users: IBMWUsers;
   constructor(
     private appService : AllLineService,
     //private modalService : BMWModalService,
    private componentFactoryResolver : ComponentFactoryResolver, 
    private injector: Injector, private router: Router) {
        
    }
      ngOnInit(){
        this.fetch()
//         var temp={  
//    "calculateAVPScore":"false",
//    "demoSearch":"false",
//    "mcDealer":"false",
//    "numOfItems":"0",
//    "retailDate":"09/03/2018",
//    "retails":[  
//       {  
//          "hasZRecordData":"false",
//          "id":"0",
//          "needsZRecord":"false",
//          "priorRetailedtoZ":"false",
//          "vehicle":{  
//             "chassisNumber":"NU72485",
//             "cpoIndicator":"N",
//             "inventoryValidated":"false",
//             "lineMakeDesc":"BMW Car",
//             "lineMakeId":"1",
//             "mileage":"0",
//             "modelCode":"183X",
//             "priorRetailedtoZ":"false",
//             "type":"N"
//          }
//       },
//       {  
//          "hasZRecordData":"false",
//          "id":"1",
//          "needsZRecord":"false",
//          "priorRetailedtoZ":"false",
//          "vehicle":{  
//             "chassisNumber":"NV03177",
//             "cpoIndicator":"N",
//             "inventoryValidated":"false",
//             "lineMakeDesc":"BMW Car",
//             "lineMakeId":"1",
//             "mileage":"0",
//             "modelCode":"18TM",
//             "priorRetailedtoZ":"false",
//             "type":"N"
//          }
//       }
// ],
//    "useLocations":"false"
// }
  //this.users =temp;
  console.log(this.users)
    }
      fetch(){
        this.appService.getUsers().subscribe(res => {this.users = res        
        console.log(this.users)
        });
       
       }
      retailInfo(){

       this.router.navigate(['tab2'])
        // let modaloption = new BMWModalOptions();
        // modaloption.modalId= "retailDetails";
        // modaloption.modalTitle="";
        // modaloption.keyboard= true;
        // modaloption.showClose = false;

        // this.modalService.open(rcdComponent, modaloption,{},
        //     this.componentFactoryResolver,this.injector);
        // this.modalService.onClose(modaloption.modalId).subscribe(isClose=>{});

      }
}
