import {IBMWServerResponse} from 'app/core/resource/resource.model'

export interface IBMWUsers extends IBMWServerResponse{
    calculateAVPScore? : boolean,
    demoSearch? : boolean,
    mcDealer? : boolean,
    numOfItems? : string,
    retailDate? : string,
    retails ? : IBMWRetail,
    useLocations? : boolean
}
export interface IBMWRetail{
    hasZRecordData? : boolean,
    id? : string,
    needsZRecord? : boolean,
    priorRetailedtoZ? : boolean,
    vehicle? : IBMWVehicle
}

export interface IBMWVehicle{
            chassisNumber ?:string,
            cpoIndicator ?:string,
            inventoryValidated?: boolean,
            lineMakeDesc?: string,
            lineMakeId?: string,
            mileage?: string,
            modelCode?: string,
            priorRetailedtoZ?: boolean,
            type ?:string
}
