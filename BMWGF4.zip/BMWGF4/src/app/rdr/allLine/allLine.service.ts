import { Injectable } from '@angular/core';
import{environment} from "environments/environment"
// import { Http, Headers, RequestOptions } from '@angular/http';
// import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { Observable } from "rxjs/Rx";
import {IBMWResourcePayload, IBMWServerResponse} from 'app/core/resource/resource.model'
import {tabList} from 'app/core/resource/resource.config'
import {BMWResourceService} from 'app/core/resource/resource.service'

@Injectable()
export class AllLineService {
  
  public token: string;
  result:any;
  apiEndpoint: string;
  constructor(private resouceService : BMWResourceService) { 
    this.apiEndpoint = environment.apiEndpoint
  }
  private handleError(error: Response) {
        return Observable.empty();
    }
  getUsers(): Observable<any>{    
    let payload: IBMWResourcePayload ={
      uri: tabList.uri,
      method: tabList.method
    }
    return this.resouceService.request(tabList,payload)
    .map((response: IBMWServerResponse) =>{
      if(response)
        return response
    }).catch(this.handleError)
  }
}