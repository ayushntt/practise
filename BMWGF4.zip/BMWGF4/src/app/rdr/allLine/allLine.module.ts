import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AllLineComponent } from 'app/rdr/allLine/allLine.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [AllLineComponent],
  exports:[]
})
export class FirstTabModule {
  constructor(){console.log("first-tab called")}
 }
