import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RDRComponent } from 'app/rdr/RDR.component';
import { HeaderComponent } from './header.component';
import {RDRRoutingModule} from 'app/rdr/rdr-routing.module'
import{AllLineComponent} from 'app/rdr/allLine/allLine.component'
import{BMWCarComponent} from 'app/rdr/bmwCar/bmwCar.component'
import{AllLineService} from 'app/rdr/allLine/allLine.service'
//import{SecondTabComponent} from 'app/first/second-tab/second-tab.component'
//import{rcdComponent} from 'app/first/first-tab/rcd.component'


@NgModule({
  imports: [
    CommonModule,
    RDRRoutingModule,
    FormsModule
  ],
  declarations: [RDRComponent, HeaderComponent, AllLineComponent, BMWCarComponent],
  exports:[RDRComponent],
  providers:[AllLineService]
  //entryComponents:[rcdComponent]
})
export class RDRModule {
  constructor(){console.log("first called")}
 }