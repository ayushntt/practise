import { NgModule, Optional, SkipSelf, ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BMWErrorService } from "app/core/error/error.service";
import { BMWResourceService } from "app/core/resource/resource.service";
import { BMWErrorHandler } from "app/core/error/error-handler.service";
import { BMWToastService } from "app/core/messages/toastr.service";
import { HttpClientModule } from "@angular/common/http";
// import {BMWModalComponent} from "app/core/modal/modal.component"
// import {BMWModalService} from "app/core/modal/modal.service"

@NgModule({
    imports: [CommonModule, HttpClientModule],
    //exports:[BMWModalComponent],
    //declarations:[BMWModalComponent],
    providers: [BMWErrorService, 
                BMWResourceService,  
                BMWToastService, 
                HttpClientModule,
                //BMWModalService,
                {provide: ErrorHandler, useClass: BMWErrorHandler}
    ]
})
export class BMWCoreModule{
    constructor (@Optional() @SkipSelf() parentModule: BMWCoreModule) {
        if (parentModule) {
            throw new Error('BMWCoreModule is already loaded. Import it in the AppModule only');
        }
    }
}