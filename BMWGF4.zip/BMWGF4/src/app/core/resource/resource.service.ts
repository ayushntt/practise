import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Http, Response, Headers, RequestOptions, ResponseContentType } from '@angular/http'

import { environment } from 'environments/environment';
import {AppConstants} from 'app/app.constants';
import {IBMWResourceApi,IBMWResourcePayload, BMWHttpMethods, BMWRequestType, BMWResponseType} from './resource.model';
import { BMWError } from "app/core/error/error.model";
import { BMWMessages } from "app/core/messages/messages.constants";
import { Router } from "@angular/router";
import { error } from 'util';


@Injectable()
export class BMWResourceService {

    apiEndpoint: string;
    defaultHeaders: {[name: string]: any};
    defaultRequestType: BMWRequestType;
    authHeader: {[name: string]: any};

    constructor(private http: Http, private router: Router) { 
        this.apiEndpoint = environment.apiEndpoint;
        this.defaultHeaders = {};
        this.defaultHeaders[AppConstants.headerContentType] = AppConstants.contentTypeJson;
        this.defaultRequestType = BMWRequestType.Json;
    }

    request(api: IBMWResourceApi, payload: IBMWResourcePayload): Observable<any>{
        //1. Construct url
        let url = this.buildUrl(api, payload);
        //2. Append headers to default ones
        //3. Check if resource is secured and set authorization header 
        //4. Check request type and set content-type
        let headers = new Headers(this.buildHeaders(api, payload));
        let options = new RequestOptions({headers: headers});
        //4. Check method type and forward to appropriate function
        // override responseType for blob
        if(api.responseType == BMWResponseType.Blob) {
            options = new RequestOptions({responseType: ResponseContentType.Blob,headers: headers});
        }
        let response = this.sendRequest(url, api.method, options, this.buildBody(api, payload));
        //5. Check response type and extract data
        return this.handleResponse(api, response);                
    }

    private buildUrl(api: IBMWResourceApi, payload: IBMWResourcePayload): string{
        let allowedParams = api.params;
        let url = api.uri;
        let searchUri = ''; 
        // find path variables in the uri
        if (allowedParams) {
            allowedParams.forEach(value => {
                if (url.includes(`/:${value}`) && payload.params[value]) {
                    url = url.replace(`/:${value}`, `/${payload.params[value]}`);
                } else if (payload.params[value]) {
                    searchUri === '' ? searchUri = `?${value}=${encodeURIComponent(payload.params[value])}` : searchUri = `${searchUri}&${value}=${encodeURIComponent(payload.params[value])}`;
                }
            })
        }
        url = `${this.apiEndpoint}${url}${searchUri}`;
        return url;
    }

    private buildHeaders(api: IBMWResourceApi, payload: IBMWResourcePayload) : {[name: string]: any}{
        let headers = {};        
        let requestType = this.defaultRequestType;
        if(api.requestType){
            requestType = api.requestType;
        }
        switch(requestType){
            case BMWRequestType.Json: {
                Object.assign(headers, this.defaultHeaders);
            }                   
        }        
        if(api.secured && this.authHeader){
           Object.assign(headers, this.authHeader);
        }
        Object.assign(headers, api.headers, payload.headers);
        return headers;
    }

    private buildBody(api: IBMWResourceApi, payload: IBMWResourcePayload){
        let requestType = this.defaultRequestType;
        if(api.requestType){
            requestType = api.requestType;
        }
        if(requestType === BMWRequestType.Json){
            return JSON.stringify(payload.body);
        }else{
            return payload.body;
        }
    }

    private sendRequest(url: string, method: BMWHttpMethods, options: RequestOptions, data: any) : Observable<Response>{
        let response: Observable<Response>;
        switch(method) {
            case BMWHttpMethods.GET: {
                response = this.http.get(url, options);
                break;
            }
            case BMWHttpMethods.POST: {
                response = this.http.post(url, data, options);
                break;
            }                
            case BMWHttpMethods.PATCH: {
                response = this.http.patch(url, data, options);
                break;
            }               
            case BMWHttpMethods.PUT: {
                response = this.http.put(url, data, options);
                break;
            }                
            case BMWHttpMethods.DELETE:{
                response = this.http.delete(url, options);
                break;
            }                
            default:
                return this.handleError("HTTP Method not supported");
        }
        return response;
    }

    private handleResponse(api: IBMWResourceApi, response: Observable<any>): Observable<any>{
        return response.map(res => {    
            if(res._body){
                let contentType = res.headers.get(AppConstants.headerContentType);
                if(contentType.includes('json') && api.responseType === BMWResponseType.Json){
                    return res.json();
                }else if(contentType.includes('image') && 
                        api.responseType === BMWResponseType.Image){
                    return `data:${contentType};base64,${res.json()}`;        
                }
                else if(!contentType.includes('json') && !contentType.includes('image') && 
                    api.responseType === BMWResponseType.Image){
                return `data:${contentType};base64,${res.json()}`;        
                }else if(!contentType.includes('json') && !contentType.includes('image') && !contentType.includes('image') && 
                        api.responseType === BMWResponseType.Blob){
                    let filename = res.headers.get('filename');
                    return {filename:filename,blob:res._body};
                } else{
                    return res._body;
                }
            }
        })
        .catch((err: Response) => {
            if(err.status === 401){
                this.router.navigate(['login']);
            }
            throw this.buildHttpError(err);
        });;
    }

    private handleError(message:string) : Observable<any>{
        return Observable.throw(new BMWError(message));
    }

    // setAuthHeader(authToken: string){
    //     this.authHeader = {};
    //     this.authHeader[AppConstants.headerAuthorization] = authToken;
    // }

    // clearAuthHeader(){
    //     this.authHeader = undefined;
    // }

    private buildHttpError(httpResponse: Response) : BMWError{
        let error : BMWError;    
        let contentType = httpResponse.headers.get(AppConstants.headerContentType);    
        let details = 
        `Details:-
        URL: ${httpResponse.url}
        Headers: ${JSON.stringify(httpResponse.headers)}`;
                
        if ((<any>httpResponse)._body) {
            if (contentType.includes('json')) {
                let errBody = httpResponse.json();
                if (Array.isArray(errBody)) {
                    let errMessage = this.buildErrorMessage(errBody);
                    if(errMessage !== ''){
                        error = new BMWError(errMessage, httpResponse.status); 
                    }
                } else if (typeof errBody === 'object') {
                    if(errBody.message){
                        error = new BMWError(errBody.message, httpResponse.status); 
                    }                    
                }              
            }else{
                error = new BMWError((<any>httpResponse)._body, httpResponse.status); 
            }
        }
        if(!error){
            error = new BMWError(`HTTP Error ${httpResponse.status}`, httpResponse.status); 
        }
        error.details = `${details}
        Message: ${error.message}`
        if(BMWMessages['HTTP_'+ httpResponse.status]){
            error.details = `${error.details}
            Error: ${BMWMessages['HTTP_'+ httpResponse.status]}`
        }
        return error;
    }

    private buildErrorMessage(errBody: any[]){
        let message: string = '';
        errBody.forEach(err => message = `${message} ${err.message}`);
        return message;
    }
}