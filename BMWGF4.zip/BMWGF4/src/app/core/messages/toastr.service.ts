import { Injectable } from '@angular/core';
import * as toastr from 'toastr';

@Injectable()
export class BMWToastService {

    constructor() {
        toastr.options.closeButton = true;
    }

    info(message: string, title?: string, overrides?: ToastrOptions){
        toastr.info(message, title, overrides);
    }

    warning(message: string, title?: string, overrides?: ToastrOptions){
        toastr.warning(message, title, overrides);
    }

    error(message: string, title?: string, overrides?: ToastrOptions){
        toastr.error(message, title, overrides);
    }

    success(message: string, title?: string, overrides?: ToastrOptions){
        toastr.success(message, title, overrides);
    }

    clear(){
        toastr.clear();
    }
}