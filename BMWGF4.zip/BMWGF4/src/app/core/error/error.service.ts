import { Injectable } from '@angular/core';
import { Response } from '@angular/http';

import { BMWError } from "./error.model";

@Injectable()
export class BMWErrorService {

    constructor() { 
    }

    logError(error: any){
        let pracError : BMWError;
        if(error instanceof Error){
            pracError = (<BMWError>error);
        }else{
            pracError = new BMWError(`Unknown Error`);
            pracError.details = JSON.stringify(error);
        }
        this.printConsole(pracError);       
    }

    private printConsole(error: BMWError){
        let printErr = 
        `Error:${error.code? error.code: ''} ${error.message}
        ${error.details? error.details: ''}
        ${error.stack}`;
        console.error(printErr);
    }
}